@extends('layouts.front')
@section('content')
    <a href="/admin/auth/login">الذهاب الى لوحة التحكم</a>
@endsection
