@extends('layouts.admin')

@section('title')
	تقارير الفترات
@endsection

@section('pageHeading')
	تقرير الفترات
@endsection

@section('content')
	<div class="container">
		<fieldset>
			<legend class="custom-bg">العقود التى سوف تنتهى قبل 7 أيام</legend>
			<div class="accordion mt-5" id="ContractsPeriods">
				@php $a=0 @endphp {{-- Display First item Only --}}
				@foreach ($contracts as $contract)
					{{-- Start Looping Contracts --}}
					@if ($contract->remainingDays > 0 && $contract->remainingDays <= 7)
						{{-- Fitering Contracts according to status and remaining days --}}
						<div class="accordion-item">
							{{-- Start of accordion Item --}}
							<h2 class="accordion-header">
								<button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#collapse_{{ $contract->id }}" type="button"
									aria-expanded="{{ $a === 0 ? 'true' : 'false' }}" aria-controls="collapse_{{ $contract->id }}">
									{{ str_pad(++$a, 3, '0', STR_PAD_LEFT) }} - {{ $contract->the_client->a_name }} - الوقت المتبقى {{ $contract->remainingDays }} يوم/أيام
								</button>
							</h2>

							<div class="accordion-collapse collapse {{ $a === 1 ? 'show' : '' }}" id="collapse_{{ $contract->id }}" data-bs-parent="#ContractsPeriods">
								<div class="accordion-body">
									@foreach ($contract->periods as $period)
										<div class="input-group">
											<label class="input-group-text" for="">{{ __('الكـــود') }}</label>
											<label class="form-control" for="">{{ $period->the_code }}</label>
											<label class="input-group-text" for="">{{ __('بدأت من:') }}</label>
											<label class="form-control" for="">{{ $period->starts_in }}</label>
											<label class="input-group-text" for="">{{ __('تنتهي فى:') }}</label>
											<label class="form-control" for="">{{ $period->ends_in }}</label>
											<label class="input-group-text" for="">{{ __('الحالة:') }}</label>
											<label class="form-control" for="">{{ $period->status === 1 ? 'نشطة' : 'منتهية' }}</label>
										</div>
									@endforeach
									{{ $contract->periods }}
									<a calss="btn btn-outline-primary btn-sm" href="{{ route('contract.edit', [$contract->id, 1]) }}">{{ $contract->s_number }}</a>
								</div>
							</div>
						</div>
						
					@endif
					{{-- End of Contracts Fitering --}}
				@endforeach
				{{-- End Looping Contracts --}}
			</div>
		</fieldset>
	</div>
@endsection

@section('script')
	<script></script>
@endsection
