<div class="content-wrapper" style="min-height: 100vh; padding-top: 80px">
    @include('admin.includes.alerts.failure')
    @include('admin.includes.alerts.success')
    @yield('content')
</div>
