<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ContractItem extends Model
{
    use HasFactory;
    protected $table = 'contract_items';
    protected $fillable = [
        'item', 'qty', 'unit', 'price', 'status', 'contract',
        'company', 'created_by', 'updated_by', 
        'created_at', 'updated_at'];

    public static function getLargePalletsFor($contractId) {
        $ls = self::where(['contract'=>$contractId, 'item'=>2])->first();
        return $ls == null ? 0 : $ls->qty;
    }
    public static function getSmallPalletsFor($contractId) {
        $ls = self::where(['contract'=>$contractId, 'item'=>1])->first();
        return $ls == null ? 0 : $ls->qty;
    }

}
