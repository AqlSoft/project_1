
<footer class="my-custom-footer">
  <!-- To the right -->
  <div class="float-right d-none d-sm-inline">
    Anything you want
  </div>
  <!-- Default to the left -->
  <strong>Copyright &copy; 2014-2025 <a href="#" style="color: inherit">www.aklsoft.net</a>.</strong> All rights reserved. AKLSOFT<sup>TM</sup>
</footer>