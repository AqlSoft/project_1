@extends('layouts.admin')

@section('title')
    تقارير الطبالي
@endsection

@section('pageHeading')
    أرصدة الطبالى لدى العملاء
@endsection

{{-- This view is created to pick a contract to calculate tables stats / creadit --}}
@section('content')
    <div class="container">
        <fieldset>
            <legend>
                ابحث عن عقد
            </legend>

            <div class="row pt-3">
                <div class="col col-4">
                    <div class="input-group">
                        <input type="text" class="form-control" name="search_by_client" id="search_by_client"
                            placeholder="البحث باسم العميل">
                        <label for="search_by_client" class="input-group-text" id="search_by_client_btn"
                            data-search-url="{{ route('search.contracts.by.client') }}"
                            data-search-token="{{ csrf_token() }}">
                            <i class="fa fa-search"></i>
                        </label>
                    </div>
                </div>
            </div>
            <div id="clients_data"></div>
            <div id="contract_data"></div>
            <form action="{{ route('search.contracts.by.client') }}">
                @csrf

            </form>
        </fieldset>
    </div>
@endsection

@section('script')
    <script>
        $(document).ready(function() {
            $(document).on('click', '#search_by_client_btn', function() {
                console.log('excuted')
                let url = $('#search_by_client_btn').attr('data-search-url');
                let token = $('#search_by_client_btn').attr('data-search-token');
                let query = $('#search_by_client').val();

                jQuery.ajax({
                    url: url,
                    type: 'post',
                    dataType: 'html',
                    data: {
                        query: query,
                        '_token': token,
                        url: url
                    },
                    cash: false,
                    success: function(data) {
                        $('#clients_data').html(data);
                    },
                    error: function() {

                    }
                });
            });

            $(document).on('click', '#clientsList button.showContractStats', function(e) {

                let url = $(this).attr('data-href');
                let token = $(this).attr('data-token');
                let contract = $(this).attr('data-id');

                jQuery.ajax({
                    url: url,
                    type: 'post',
                    dataType: 'html',
                    data: {
                        contract: contract,
                        '_token': token
                    },
                    cash: false,
                    success: function(data) {
                        console.log(data);
                        $('#contract_data').html(data);
                    },
                    error: function() {
                        console.log('error happened')
                    }
                });
            });

        });
    </script>
@endsection
