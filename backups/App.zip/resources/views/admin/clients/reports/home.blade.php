@extends('layouts.admin')

@section('title')
    التقارير | الرئيسية
@endsection

@section('pageHeading')
    تقارير العملاء
@endsection

@section('content')
    <div class="container pt-5" style="min-height: 100vh">
        <div class="cards">
            <div class="card w-100">
                <div class="card-body row">

                    <div class="col col-3 text-center mb-3">
                        <div class="border border-info">
                            <div class="p-5"><i data-bs-toggle="tooltip" data-bs-title="جميع العقود"
                                    class="text-primary fa-3x fas fa-folder-open"></i></div>
                            <a href="{{ route('clients.reports.contracts') }}" class="p-2 fs-4 d-block bg-info"> جميع
                                العقود
                            </a>
                        </div>
                    </div>

                    <div class="col col-3 text-center mb-3">
                        <div class="border border-info">
                            <div class="p-5">
                                <i data-bs-toggle="tooltip" data-bs-title="تقارير الطبالى"
                                    class="text-primary fa-3x fas fa-file-invoice-dollar"></i>
                            </div>
                            <a href="{{ route('table.report') }}" class="p-2 fs-4 d-block bg-info"> تقارير
                                الطبالى
                            </a>
                        </div>
                    </div>

                    <div class="col col-3 text-center mb-3">
                        <div class="border border-info">
                            <div class="p-5"><i data-bs-toggle="tooltip" data-bs-title="تقارير الأصناف"
                                    class="text-primary fa-3x fas fa-file-invoice"></i></div>
                            <a href="{{ route('clients.reports.storeitems') }}" class="p-2 fs-4 d-block bg-info"> تقارير
                                الأصناف
                            </a>
                        </div>
                    </div>

                    <div class="col col-3 text-center mb-3">
                        <div class="border border-info">
                            <div class="p-5"><i data-bs-toggle="tooltip" data-bs-title="تقرير الاصناف فى جدول"
                                    class="text-primary fa-3x fas fa-table"></i></div>
                            <a href="" class="p-2 fs-4 d-block bg-info">
                                <form action="{{ route('clients.items.stats') }}" method="POST">
                                    @csrf
                                    <input type="hidden" name="searchQuery">
                                    <button type="submit"
                                        style="border: 0; outline: none; background: transparent; color: #fff">
                                        تقارير جدول الأصناف
                                    </button>
                                </form>

                            </a>
                        </div>
                    </div>

                    <div class="col col-3 text-center mb-3">
                        <div class="border border-info">
                            <div class="p-5"><i data-bs-toggle="tooltip" data-bs-title="تقارر الكميات"
                                    class="text-primary fa-3x fas fa-sort-amount-down-alt"></i>
                            </div>
                            <a href="{{ route('reception.home', [1]) }}" class="p-2 fs-4 d-block bg-info">تقارير
                                الكميات</a>
                        </div>
                    </div>


                    <div class="col col-3 text-center mb-3">
                        <div class="border border-info">
                            <div class="p-5"><i data-bs-toggle="tooltip" data-bs-title="تقارر الكميات"
                                    class="text-primary fa-3x fas fa-sort-amount-down-alt"></i>
                            </div>
                            <a href="{{ route('contracts.table.credit') }}" class="p-2 fs-4 d-block bg-info">تقارير
                                رصيد الطبالى</a>
                        </div>
                    </div>

                    <div class="col col-3 text-center mb-3">
                        <div class="border border-info">
                            <div class="p-5"><i data-bs-toggle="tooltip" data-bs-title="السندات الملغاة والمحذوفة"
                                    class="text-primary fa-3x fas fa-calendar-days"></i></div>
                            <a href="{{ route('contracts.periods/report') }}" class="p-2 fs-4 d-block bg-info">
                                فترات العقود
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div> {{-- the End Of Card --}}




    </div>
@endsection


@section('script')
@endsection
