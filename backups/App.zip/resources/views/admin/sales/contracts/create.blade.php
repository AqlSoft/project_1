@extends('layouts.admin')


@section('title')
    العقود
@endsection

@section('pageHeading')
    إضافة عقد جديد
@endsection

@section('header_includes')
    <link rel="stylesheet" href="{{ asset('assets/admin/css/editContract.css') }}">
@endsection

@section('content')
    <div class="container">
        <div class="border">

            <fieldset dir="rtl" class="m-3 mt-5">
                <legend style="right: 20px; left: auto">إضافة عقد جديد</legend>
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home-tab-pane"
                            type="button" role="tab" aria-controls="home-tab-pane" aria-selected="true">البيانات
                            الأساسية</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#home-tab-pane"
                            type="button" role="tab" aria-controls="home-tab-pane" aria-selected="false">اصناف
                            العقد</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#home-tab-pane"
                            type="button" role="tab" aria-controls="home-tab-pane" aria-selected="false">التدفقات
                            النقدية</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="others-tab" data-bs-toggle="tab" data-bs-target="#home-tab-pane"
                            type="button" role="tab" aria-controls="home-tab-pane" aria-selected="false">شروط
                            أخرى</button>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab"
                        tabindex="0">
                        <form class="p-3" id="regForm" action="{{ route('contract.store', $client->id) }}"
                            method="post">
                            @csrf
                            <style>
                                table tr td {
                                    border-left: 0 !important;
                                    font-weight: bolder;
                                }

                                table tr td input {
                                    display: inline-block;
                                    background-color: transparent;
                                    border: 1px solid transparent;
                                    border-bottom-color: #777;
                                    margin: 0 16px
                                }
                            </style>
                            <div class="row" dir="rtl">
                                <b class="col-auto"> اسم العميل:</b> &nbsp;
                                <span class="col-auto">{{ $client->a_name }}</span>، &nbsp;
                                <b class="col-auto"> اسم المسؤول:</b> &nbsp;
                                <span class="col-auto">{{ $client->person ? $client->person : 'N/A' }}</span>، &nbsp;
                                <b class="col-auto"> الهاتف:</b> &nbsp;
                                <span class="col-auto">{{ $client->phone ? $client->phone : 'N/A' }}</span>، &nbsp;
                                <b class="col-auto"> السجل التجاري:</b> &nbsp;
                                <span class="col-auto">{{ $client->cr ? $client->cr : 'N/A' }}</span>.
                                <b class="col-auto"> الإقامة / الهوية :</b> &nbsp;
                                <span class="col-auto">{{ $client->iqama ? $client->iqama : 'N/A' }}</span>.
                            </div>

                            <div class="label text-right font-weight-bold">الترقيم</div>

                            <table class=" w-100">
                                <tr>
                                    <td class="text-left">نوع العقد:</td>
                                    <td class="">
                                        <select name="type" id="type" required>

                                            <option value="1">عقد تأجير أساسى</option>
                                            <option value="2">زيادة عدد طبالى</option>
                                            <option value="3">تمديد مدة عقد</option>
                                        </select>
                                    </td>
                                    <td class="text-left">الكود:</td>
                                    <td class="">
                                        <input type="text" name="code" id="code" value="{{ $cCode }}"
                                            required>
                                    </td>
                                    <td class="text-left">الرقم المسلسل:</td>
                                    <td class="">
                                        <input type="text" name="s_number" id="s_number" value="{{ $lastContract }}"
                                            required>
                                    </td>
                                </tr>
                            </table>

                            <div class="label text-right font-weight-bold">الموعد</div>

                            <table class=" w-100">
                                <tr>
                                    <td class="text-left">في يوم:</td>
                                    <td class="cal-1">
                                        <input type="date" class="dateGrabber" data-target="in_day" style="width: 30px"
                                            id="in_day">
                                        <span style="padding: 0 1em;" id="in_day_greg_display">result</span>
                                        <input type="hidden" name="in_day_greg_input" id="in_day_greg_input">
                                    </td>
                                    <td class="text-left">الموافق:</td>
                                    <td class="cal-2">
                                        <span style="padding: 0 1em;" id="in_day_hijri_display">result</span>
                                        <input type="hidden" name="in_day_hijri_input" id="in_day_hijri_input">
                                    </td>
                                </tr>
                            </table>
                            <br>
                            <h4 class="mt-3">التوقيت والمدة</h4>
                            <table class="w-100">
                                <tr>
                                    <td>
                                        <div class="input-group">
                                            <label class="input-group-text" for="start_period"> الفترة المبدئية:</label>
                                            <input type="number" class="form-control m-0" name="start_period"
                                                id="start_period" value="3">
                                            <label class="input-group-text">شهر/أشهر</label>

                                            <select name="renewable" id="renewable" class="form-control">
                                                <option value="true">قابلة للتجديد</option>
                                                <option value="true">غير قابلة للتجديد</option>
                                            </select>

                                            <label class="input-group-text" for="renew_period">
                                                لمدة:</label>
                                            <input type="number" class="form-control m-0" name="renew_period"
                                                id="renew_period" value="1">
                                            <label class="input-group-text">شهر/أشهر</label>
                                        </div>
                                    </td>

                                </tr>
                            </table>
                            <h4 class="mt-3">التوقيت والمدة</h4>
                            <table class="w-100">
                                <tr>
                                    <td class="text-left">بداية العقد:</td>
                                    <td class="cal-1" colspan="2">
                                        <input type="date" class="dateGrabber" data-target="starts_in"
                                            style="width: 30px" id="starts_in">
                                        <span style="padding: 0 1em;" id="starts_in_greg_display">result</span>
                                        <input type="hidden" name="starts_in_greg_input" id="starts_in_greg_input">
                                    </td>
                                    <td class="text-left">الموافق:</td>
                                    <td class="cal-2" colspan="2">
                                        <span style="padding: 0 1em;" id="starts_in_hijri_display">result</span>
                                        <input type="hidden" name="starts_in_hijri_input" id="starts_in_hijri_input">
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-left">نهاية العقد:</td>
                                    <td class="cal-1" colspan="2">
                                        <input type="date" class="dateGrabber" data-target="ends_in"
                                            style="width: 30px" id="ends_in">
                                        <span style="padding: 0 1em;" id="ends_in_greg_display">00/00/2000</span>
                                        <input type="hidden" name="ends_in_greg_input" id="ends_in_greg_input">
                                    </td>
                                    <td class="text-left">الموافق:</td>
                                    <td class="cal-2" colspan="2">
                                        <span style="padding: 0 1em;" id="ends_in_hijri_display">00/00/1400</span>
                                        <input type="hidden" name="ends_in_hijri_input" id="ends_in_hijri_input">
                                    </td>
                                </tr>
                            </table>
                            <!-- One "tab" for each step in the form: -->
                            <div style="">
                                <br>
                                <button id="dismiss_btn" class="btn btn-success"
                                    onclick="window.location='{{ route('clients.home') }}'">إلغاء</button>
                                <button class="btn btn-secondary" type="submit" id="submitBtn">إدراج</button>
                            </div>
                        </form>
                    </div>
                    {{-- <div class="tab-pane fade" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab" tabindex="0">...</div>
                    <div class="tab-pane fade" id="contact-tab-pane" role="tabpanel" aria-labelledby="contact-tab" tabindex="0">...</div>
                    <div class="tab-pane fade" id="disabled-tab-pane" role="tabpanel" aria-labelledby="disabled-tab" tabindex="0">...</div> --}}
                </div>
            </fieldset>
        </div>
    </div>


    </div>
@endsection
@section('script')
    <script type="text/javascript">
        function fillInFields(el) {
            let total = parseFloat(document.getElementById(el.id + 'Value').innerHTML = document.getElementById(el.id +
                'MonthlyAmount').innerHTML * 3.00 * el.value)
            let Vat = document.getElementById(el.id + 'VAT').innerHTML = document.getElementById(el.id + 'MonthlyAmount')
                .innerHTML * 3.00 * el.value * 0.15
            document.getElementById(el.id + 'AfterVat').innerHTML = total + Vat;
            let aaa = parseFloat(document.getElementById('smallTablesAfterVat', 10).innerHTML)
            let bbb = parseFloat(document.getElementById('largeTablesAfterVat', 10).innerHTML)
            let ccc = parseFloat(document.getElementById('smallRoomsAfterVat', 10).innerHTML)
            let ddd = parseFloat(document.getElementById('largeRoomsAfterVat', 10).innerHTML)
            totalsSum.innerHTML = aaa + bbb + ccc + ddd
        }
    </script>
    <script>
        let dateInputs = ['in_day', 'starts_in', 'ends_in'];
        window.onload = function() {
            dateInputs.forEach((id) => {
                const dateInput = document.getElementById(id)
                updateOnload(id)

                dateInput.onchange = function(e) {
                    updateOnchange(e.target.id)
                }
            })
        }

        function updateOnload(id) {
            let today = new Date();
            document.getElementById(id + '_greg_display').innerHTML = today.toLocaleDateString('ar-eg')
            document.getElementById(id + '_greg_input').value = dateFormatNumeral(today)
            document.getElementById(id + '_hijri_display').innerHTML = today.toLocaleDateString('ar-sa')
            document.getElementById(id + '_hijri_input').value = today.toLocaleDateString('ar-sa')
        }

        function updateOnchange(id) {
            let today = new Date(document.getElementById(id).value);
            document.getElementById(id + '_greg_display').innerHTML = today.toLocaleDateString('ar-eg')
            document.getElementById(id + '_greg_input').value = dateFormatNumeral(today)
            document.getElementById(id + '_hijri_display').innerHTML = today.toLocaleDateString('ar-sa')
            document.getElementById(id + '_hijri_input').value = today.toLocaleDateString('ar-sa')
        }

        function dateFormatNumeral(date) {
            return date.getFullYear() + '-' + [date.getMonth() + 1] + '-' + date.getDate();
        }
    </script>
@endsection
