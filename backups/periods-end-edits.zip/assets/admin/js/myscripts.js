const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))


// Personal Navs and Tabs

// $(document).on('click', '.navBtn', (evt) => {
//     console.log(__parent_id)
//     const __id = evt.target.getAttribute('data-target')
//     $('.tabs .tabItem').removeClass('show')
//     $(__id).addClass('show');
// })

$(document).on('click', '.navBtn', (evt) => {
    const __id = evt.target.getAttribute('data-target')
    const _btn = evt.target
    const __parent_id = $(__id).attr('data-parent')

    // If user clicked icon  nothing is depricated
    // if (_btn.classList.contains('fa')) return
    console.log(__id, __parent_id, _btn)
    $(__parent_id + ' ' + ' nav.tabsDisplay>button').removeClass('active')
    _btn.classList.add('active')

    $(__parent_id + ' .tabs .tabItem').removeClass('show')
    $(__parent_id + ' ' + __id).addClass('show');
})
