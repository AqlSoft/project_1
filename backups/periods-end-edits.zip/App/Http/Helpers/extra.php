<?php
namespace App\Helpers;

class Extra {
    public static function edit ($id, $props) {
        return 'Working';
    }
}
