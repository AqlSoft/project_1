@extends('layouts.admin')
@section('title')
	أصناف التخزين
@endsection
@section('pageHeading')
	اسماء الأصناف المخزنة بالثلاجة
@endsection

@section('content')
	<div class="container pt-3">
		<style>
			.item {
				height: 72px;
				border: 1px solid #cde;
				margin: 3px 8px;
				overflow: hidden;
				display: flex;
			}

			.item-image {
				height: 72px;
				width: 80px;
				background-color: #333;
				background-size: cover;
			}

			.item-name {
				width: calc(100%-180px);
				height: 72px;
				text-align: right;
				width: calc(100% - 80px);
			}

			.item-controls {
				display: inline-block;
				width: 180px;
				text-align: center;
			}
		</style>

		<fieldset>
			<legend>اسماء الأصناف</legend>
			<br>

			<div class="m-4 bg-light " style="box-shadow: 0 0 10px 3px #777 inset">
				<div class="buttons">
					<button class="btn btn-sm px-2 btn-outline-primary"><a href="{{ route('store.items.stats') }}"> <i class="fa fa-chart-line"></i>
							احصائيات</a></button>
					<button class="btn btn-sm px-2 btn-outline-primary"><a href="{{ route('store.items.home') }}"> <i class="fa fa-list"></i>
							الأصناف</button>
					<button class="btn btn-sm px-2 btn-success"><a> <i class="fa fa-tags"></i>
							الفئات</button>
					<button class="btn btn-sm px-2 btn-outline-secondary"><a href="{{ route('store-items-grades-list') }}"> <i class="fa fa-ranking-star"></i></a>
						الدرجات</button>
				</div>
			</div>

			<div class="search mr-4">
				<form method="POST">
					<div class="row mb-3">
						<div class="col col-5">
							<div class="input-group">
								<label class="input-group-text" for="aj_search">البحث فى الفئات</label>
								<input class="form-control bg-light" id="aj_search" data-search-token="{{ csrf_token() }}" data-search-url="{{ route('treasuries.aj') }}"
									type="text" name="search">
								<label class="input-group-text" for="aj_search"><i class="fa fa-search"></i></label>
							</div>
						</div>
					</div>
				</form>

			</div>

			<div class="m-4 bg-light " style="box-shadow: 0 0 10px 3px #777 inset">

				<div class="row p-3">
					{{--  storage\app\admin\uploads\images\store_item_1710668689.png --}}
					@if (count($categories))
						@foreach ($categories as $in => $item)
							<div class="col col-12 col-sm-6">
								<div class="item">
									<div class="item-image"
										style="width: 50px; height: 50px; margin: 0.5rem; background-image: url('{{ url('assets/admin/uploads/images', $item->image) }}'); background-size: 100% 100%; border-radius: 50%">
									</div>
									<div class="item-name pr-3 fw-bold">
										{{ $item->parent_id === 1 ? '' : $item->parent->name . ' > ' }}{{ $item->name }}

										<div class="buttons">
											<button class="btn btn-outline-success btn-sm"><a href="{{ route('store-items-categories-edit', [$item->id]) }}"> <i
														class="fa fa-edit text-success"></i> تعديل </a></button>
											<button class="btn btn-outline-primary btn-sm"><a href="{{ route('store.items.view', [$item->id]) }}"><i class="fa fa-eye text-primary"></i>
													رؤية المزيد </a></button>
											<button class="btn btn-outline-danger btn-sm"><a href="{{ route('store.items.remove', [$item->id]) }}"><i
														class="fa fa-trash text-danger"></i> حذف </a></button>
										</div>
									</div>
								</div>
							</div>
						@endforeach
					@else
						<div class="col col-12 text-right">لم تتم إضافة فئات بعد، استخدم النموذج بالأسفل لإضافة فئات للتطبيق.</div>
					@endif
				</div>

				<form class="p-4" action="{{ route('store-items-categories-store') }}" method="POST" enctype="multipart/form-data">
					@csrf
					<div class="input-group">
						<label class="input-group-text required" for="parent">اسم الفئة الرئيسية</label>
						<select class="form-control" id="parent" name="parent" value="{{ old('parent') }}">
							<option value="1">فئة رئيسية</option>
							@if (count($categories))
								{
								@foreach ($categories as $category)
									<option value="{{ $category->id }}">{{ $category->parent->name }} > {{ $category->name }}</option>
								@endforeach
								}
							@endif
						</select>
						<label class="input-group-text required" for="name">اسم الفئة</label>
						<input class="form-control" id="name" required type="text" name="name" value="{{ old('name') }}">
						<input class="form-control" id="pic" type="file" name="pic" value="{{ old('pic') }}">
					</div>
					<div class="input-group mt-2">
						<label class="input-group-text" for="brief">الوصف المختصر للفئة</label>
						<input class="form-control" id="brief" type="text" name="brief" value="{{ old('brief') }}">
						<button class="input-group-text" type="submit">الحفظ</button>
					</div>
				</form>
			</div>
		</fieldset>
		<br>
	</div>
@endsection

@section('script')
	<script type="text/javascript" src="{{ asset('assets/admin/js/treasury/search.datatables.js') }}"></script>

	<script>
		function fetchData(url) {
			document.addEventListener('click', callback(e))
		}
	</script>
@endsection
