<ul>
    <li class="parent_li" role="treeitem">

        <input type="button" class="press ChartPress" id="node_23744">
        <span class="Collapse this branch context-menu-one " id="23744" level="1" title="مستلزمات شبكات المياه">
(1)مستلزمات شبكات المياه
                </span>
        <ul>
            <li class="parent_li" role="treeitem">

                <span class="context-menu-one Collapse this branch " id="23745" level="2" title="مواسير كربون ستيل">
(1.1)مواسير كربون ستيل
                </span>
                <ul>
                    <li class="parent_li" role="treeitem">

                <span class="context-menu-one "  data-jstree='{"disabled":true}' id="23789" accountId="" level="3" typeId="" title="سملس" url="">
(1.1.1)سملس
                </span>
                    </li>
                    <li class="parent_li" role="treeitem">

                <span class="context-menu-one "  data-jstree='{"disabled":true}' id="23790" accountId="" level="3" typeId="" title="ملحوم ERW" url="">
(1.1.2)ملحوم ERW
                </span>
                    </li>
                    <li class="parent_li" role="treeitem">

                <span class="context-menu-one "  data-jstree='{"disabled":true}' id="23791" accountId="" level="3" typeId="" title="ملحوم LSAW" url="">
(1.1.3)ملحوم LSAW
                </span>
                    </li>
                    <li class="parent_li" role="treeitem">

                <span class="context-menu-one "  data-jstree='{"disabled":true}' id="23792" accountId="" level="3" typeId="" title="ملحوم SSAW" url="">
(1.1.4)ملحوم SSAW
                </span>
                    </li>


                </ul>
            </li>
            <li class="parent_li" role="treeitem">

                <span class="context-menu-one Collapse this branch " id="23793" level="2" title="قطع توصيل كربونستيل">
(1.2)قطع توصيل كربونستيل
                </span>
                <ul>
                    <li class="parent_li" role="treeitem">

                <span class="context-menu-one "  data-jstree='{"disabled":true}' id="23794" accountId="" level="3" typeId="" title="كوع متساو طويل" url="">
(1.2.1)كوع متساو طويل
                </span>
                    </li>
                    <li class="parent_li" role="treeitem">

                <span class="context-menu-one "  data-jstree='{"disabled":true}' id="23795" accountId="" level="3" typeId="" title="كوع متساو قصير" url="">
(1.2.2)كوع متساو قصير
                </span>
                    </li>
                    <li class="parent_li" role="treeitem">

                <span class="context-menu-one "  data-jstree='{"disabled":true}' id="23796" accountId="" level="3" typeId="" title="كوع نقاص" url="">
(1.2.3)كوع نقاص
                </span>
                    </li>
                    <li class="parent_li" role="treeitem">

                <span class="context-menu-one "  data-jstree='{"disabled":true}' id="23797" accountId="" level="3" typeId="" title="Return Long Radius" url="">
(1.2.4)Return Long Radius
                </span>
                    </li>
                    <li class="parent_li" role="treeitem">

                <span class="context-menu-one "  data-jstree='{"disabled":true}' id="23798" accountId="" level="3" typeId="" title="رجيع قصير" url="">
(1.2.5)رجيع قصير
                </span>
                    </li>
                    <li class="parent_li" role="treeitem">

                <span class="context-menu-one "  data-jstree='{"disabled":true}' id="23799" accountId="" level="3" typeId="" title="مشترك متساو" url="">
(1.2.6)مشترك متساو
                </span>
                    </li>
                    <li class="parent_li" role="treeitem">

                <span class="context-menu-one "  data-jstree='{"disabled":true}' id="23800" accountId="" level="3" typeId="" title="مشترك نقاص" url="">
(1.2.7)مشترك نقاص
                </span>
                    </li>
                    <li class="parent_li" role="treeitem">

                <span class="context-menu-one "  data-jstree='{"disabled":true}' id="23801" accountId="" level="3" typeId="" title="نقاص مركزى" url="">
(1.2.8)نقاص مركزى
                </span>
                    </li>
                    <li class="parent_li" role="treeitem">

                <span class="context-menu-one "  data-jstree='{"disabled":true}' id="23802" accountId="" level="3" typeId="" title="نقاص لا مركزى" url="">
(1.2.9)نقاص لا مركزى
                </span>
                    </li>


                </ul>
            </li>
            <li class="parent_li" role="treeitem">

                <span class="context-menu-one Collapse this branch " id="23803" level="2" title="فلانجات كربونستيل">
(1.3)فلانجات كربونستيل
                </span>
                <ul>
                    <li class="parent_li" role="treeitem">

                <span class="context-menu-one "  data-jstree='{"disabled":true}' id="23804" accountId="" level="3" typeId="" title="فلانجات مشففة" url="">
(1.3.1)فلانجات مشففة
                </span>
                    </li>
                    <li class="parent_li" role="treeitem">

                <span class="context-menu-one "  data-jstree='{"disabled":true}' id="23805" accountId="" level="3" typeId="" title="فلانجات برقبة ملحومة" url="">
(1.3.2)فلانجات برقبة ملحومة
                </span>
                    </li>
                    <li class="parent_li" role="treeitem">

                <span class="context-menu-one "  data-jstree='{"disabled":true}' id="23806" accountId="" level="3" typeId="" title="فلانجات عمياء" url="">
(1.3.3)فلانجات عمياء
                </span>
                    </li>
                    <li class="parent_li" role="treeitem">

                <span class="context-menu-one "  data-jstree='{"disabled":true}' id="23807" accountId="" level="3" typeId="" title="فلانجات مسننة" url="">
(1.3.4)فلانجات مسننة
                </span>
                    </li>
                    <li class="parent_li" role="treeitem">

                <span class="context-menu-one "  data-jstree='{"disabled":true}' id="23808" accountId="" level="3" typeId="" title="فلانجات بسوكيت لحام" url="">
(1.3.5)فلانجات بسوكيت لحام
                </span>
                    </li>


                </ul>
            </li>
        </ul>
    </li>
</ul>
