<div class="container pb-3">
	@if (Session::has('error'))
		<div class="alert mb-3 alert-danger text-right" dir="rtl">
			{!! Session::get('error') !!}
		</div>
	@endif
</div>
