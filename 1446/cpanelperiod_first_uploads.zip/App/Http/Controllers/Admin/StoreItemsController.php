<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\File;
use Illuminate\Http\Request;

use App\Http\Controllers\info;
use App\Models\Table;
use App\Models\Area;
use App\Models\Admin;
use App\Models\Contract;
use App\Models\ContractItem;
use App\Models\StoreBox;
use App\Models\StoreItem;
use App\Models\Log;
use App\Models\SalesCategory;
!defined('PAGES') ? define ('PAGES', 10): null;
class StoreItemsController extends Controller
{
    use info;

    public function home () {
        $items = StoreItem::where([])->orderBy('id', 'ASC')->paginate(20);
        $vars = [
            'items'         => $items,
        ];
        return view ('admin.store.items.home', $vars);
    }

    public function stats () {
        $items = StoreItem::where([])->orderBy('id', 'ASC')->get();
        $vars = [
            'items'         => $items,
        ];
        return view ('admin.store.items.stats', $vars);
    }

    public function store (Request $req) {
        
        $item = new StoreItem();
        $item->name = $req->name;
        $item->short = $req->short;
        $item->pic = null;


        if($req->hasFile('pic')) {
            $fileHandler = $req->pic;

            $fileName = 'store_item_'. time() . '.' . strtolower($fileHandler->getClientOriginalExtension());
            $fileHandler->storeAs('admin/uploads/images', $fileName);
            $item->pic = $fileName;

        } 
        $item->created_at = date('Ymd H:i:s');
        $item->created_by = auth()->user()->id;
        
        if ($item->save()) {
            Log::addRecord('create', $item);
            return redirect()->back()->withSuccess('تم إضافة صنف جديد بنجاح');
        } return redirect()->back()->withError('فشلت عملية إضافة صنف جديد ');
        
    }

    public function update (Request $req) {
        
        $item = StoreItem::find($req->id);
        if (!$item) {
            return redirect () -> back () -> withError('الصنف الذى تود تعديله غير موجود');
        }
        $item->edit(
            [
                'name'=>$req->name,
                'short'=>$req->short,
                'updated_by' => auth()->user()->id,
                'updated_at' => date('Ymd H:i:s'),
            ]
        );
        
       
        
        if ($item->update()) {
            Log::addRecord('create', $item);
            return redirect()->back()->withSuccess('تم إضافة صنف جديد بنجاح');
        } return redirect()->back()->withError('فشلت عملية إضافة صنف جديد ');
        
    }

    public function change_image (Request $req) {
        
        $item = StoreItem::find($req->id);
        //return var_dump($req->id);
        if ($item) {

            $file_to_be_deleted = $item->pic;
            if($req->hasFile('pic')) {
                $uploaded = $req->pic;

                $fileName = 'store_item_'. time() . '.' . strtolower($uploaded->getClientOriginalExtension());
                $uploaded->storeAs('admin/uploads/images', $fileName);
                $item->pic = $fileName;
                $item->updated_at = date('Ymd H:i:s');
                $item->updated_by = auth()->user()->id;
                
                if ($item->save()) {
                    if(File::exists($file_to_be_deleted)) {
                        File::delete($file_to_be_deleted);
                    }
                    Log::addRecord('changeImage', $item);
                    return redirect()->back()->withSuccess('تم تغيير صورة الصنف');
                } 
            }             
        } return redirect()->back()->withError('هذا الصنف غير موجود ربما تم حذفه أو حجبه من قبل الإدارة');
        
    }

    public function edit ($id) {
        $item =StoreItem::find($id);
        if ($item) {
            $vars ['item']= $item;
            return view ('admin.store.items.edit', $vars);
        } else {
            return redirect()->route('store.items.home')->withSuccess('الصنف الذى تبحث عنه غير موجود، ربما تم حذفه أو حجبه من قبل الإدارة');
        }
        
    }

    public function view ($id) {
        $item =StoreItem::find($id);
        if ($item) {
            $vars ['item']= $item;
            return view ('admin.store.items.view', $vars);
        } else {
            return redirect()->route('store.items.home')->withSuccess('الصنف الذى تبحث عنه غير موجود، ربما تم حذفه أو حجبه من قبل الإدارة');
        }
        
    }

    public function delete ($id) {
        $item = StoreItem::where(['id' => $id])->first();
        $fileHandler = public_path('../storage/app/admin/uploads/images/' . $item->pic);
        
        if ($item->delete()) {
            if(File::exists($fileHandler)) {
                File::delete($fileHandler);
            }
            Log::addRecord('delete', $item);
            return redirect()->route('store.items.home')->withSuccess('تم حذف الصنف بنجاح');
        } return redirect()->back()->withError('فشلت عملية الحذف ');
    }

}
