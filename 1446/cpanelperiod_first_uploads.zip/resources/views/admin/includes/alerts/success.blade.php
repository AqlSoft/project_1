<div class="container pb-3">
	@if (Session::has('success'))
		<div class="alert mb-3 alert-success text-right">
			{!! Session::get('success') !!}
		</div>
	@endif
</div>
