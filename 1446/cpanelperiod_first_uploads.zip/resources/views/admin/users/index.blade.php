@extends('layouts.admin')
@section('title')
    الإعدادات العامة
@endsection
@section('pageHeading')
    الإعدادات العامة
@endsection

@section('content')
    <div class="container" style="min-height: 100vh">
        <nav>
            <div class="nav nav-tabs" id="nav-tab" role="tablist" style="border: 0">
                <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button"
                    role="tab" aria-controls="nav-home" aria-selected="true">
                    <a> الموارد البشرية </a>
                </button>
                <button class="nav-link" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button"
                    role="tab" aria-controls="nav-home" aria-selected="true">
                    <a href="{{ route('permissions.home') }}"> الصلاحيات </a>

                </button>
                <button class="nav-link " id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile"
                    type="button" role="tab" aria-controls="nav-profile" aria-selected="false">
                    <a href="{{ route('menues.home') }}"> القوائم</a>
                </button>
                <button class="nav-link " id="nav-contact-tab" data-bs-toggle="tab" data-bs-target="#nav-contact"
                    type="button" role="tab" aria-controls="nav-contact" aria-selected="false">
                    <a href="{{ route('roles.home') }}"> الادوار </a>
                </button>

                <button class="nav-link " id="nav-contact-tab" data-bs-toggle="tab" data-bs-target="#nav-contact"
                    type="button" role="tab" aria-controls="nav-contact" aria-selected="false">
                    <a href="{{-- route('rules.setting', [$user->id]) --}}"> الاعدادات </a>
                </button>
            </div>
        </nav>


        <div class="tab-content" id="nav-tabContent" style="">
            <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab"
                tabindex="0">
                <fieldset dir="rtl" class="m-3">
                    <div class="row">
                        <h4 class="col col-4"> جميع الموظفين &nbsp; &nbsp;
                            <button type="button" class="btn btn-sm btn-primary py-1 float-left" style="border-radius: 0"
                                data-bs-toggle="modal" data-bs-target="#addNewRule"><i data-bs-toggle="tooltip"
                                    title="إضافة دور جديد للتطبيق" class="fa fa-plus"></i></button>
                        </h4>

                        <div class="col col-8 input-group">
                            <label for="search" class="input-group-text"><i class="fa fa-search"></i></label>
                            <input type="text" name="search" id="search" class="form-control"
                                placeholder="ابحث فى المستخدمين">
                        </div>
                    </div>


                    <fieldset class="p-4">

                        <table dir="rtl" class="striped" style="width: 100%">
                            <thead>
                                <tr class="text-center">
                                    <th>مسلسل</th>
                                    <th>الاسم</th>
                                    <th>البريد</th>
                                    <th>مسجل منذ</th>
                                    <th>الطبيعة</th>
                                    <th>الوظيفة</th>
                                    <th>التحكم</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if (count($users))
                                    @php $i=0 @endphp @foreach ($users as $ui => $user)
                                        <tr>
                                            <td>{{ ++$i }}</td>
                                            <td>{{ $user->profile->firstName }} {{ $user->profile->lastName }} [
                                                {{ $user->profile->title }} ] </td>
                                            <td>{{ $user->email }}</td>
                                            <td>{{ $user->created_at }}</td>
                                            <td>{{ $user->profile->profession }}{{-- $professions[$user->profile->profession][1] --}}</td>
                                            <td>{{ $professions[$user->profile->profession][1] }}{{-- $professions[$user->profile->profession][1] --}}
                                            </td>
                                            <td>
                                                <a href="{{ route('users.show.basic.info', [$user->id]) }}"><i
                                                        class="fa fa-eye" data-bs-toggle="tooltip"
                                                        data-bs-title="عرض بيانات العميل"></i></a>
                                                <a href="{{ route('users.delete', $user->id) }}" data-bs-toggle="tooltip"
                                                    data-bs-title="حذف العميل"
                                                    onclick="return confirm('هل تريد حذف هذا العميل بالفعل؟، هذه الحركة لا يمكن الرجوع عنها.')"><i
                                                        class="fa fa-trash" title="حذف العميل"></i></a>

                                            </td>
                                        </tr>
                                    @endforeach
                                @else
                                    <tr>
                                        <td colspan="7">لم يتم بعد تسجيل موظفين حتى الان <a
                                                href="{{ route('users.create') }}">أدخل
                                                أول مستخدم لك فى التطبيق!</a></td>
                                    </tr>
                                @endif
                            </tbody>
                        </table>
                        {{ $users->links() }}
                    </fieldset>

                </fieldset>
            </div>

        </div>

    </div>

    {{-- Modals --}}
    <!-- Modal -->
    <div class="modal fade" id="addNewRule" tabindex="-1" aria-labelledby="addNewEmployee" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" style="width: 800px">
                <div class="modal-header mx-0 bg-secondary" style="background-color: #777">
                    <h1 class="modal-title fs-5" id="addNewEmployee">إضافة موظف جديد</h1>
                    <button type="button" class="button-close ml-1 my-1 p-1" data-bs-dismiss="modal"
                        aria-label="Close"><i class="fa fa-times"></i></button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('users.store') }}" method="post">

                        @csrf

                        <fieldset style="box-shadow: none; border: 1px solid #777">
                            <legend>اسم الدور:</legend>
                            <div class="input-group mt-3">
                                <input type="text" name="name" id="name" class="form-control" required
                                    placeholder=" اسم الدور" value="{{ old('name') }}">

                                <input type="text" name="display_name_ar" id="display_name_ar" class="form-control"
                                    required placeholder="الاسم العربى" value="{{ old('display_name_ar') }}">

                                <input type="text" name="display_name_en" id="display_name_en" class="form-control"
                                    required placeholder="الاسم اللاتيني" value="{{ old('display_name_en') }}">
                            </div>
                        </fieldset>

                        <fieldset style="box-shadow: none; border: 1px solid #777; background: #ccc4">
                            <legend> الوصف:</legend>

                            <div class="form-floating mt-3">
                                <textarea style="height: 150px" class="form-control" name="brief" id="brief" placeholder="">{{ old('brief') }}</textarea>
                                <label for="brief">نبذة عن الدور:</label>
                            </div>

                            <div class="form-check form-switch form-check-reverse mt-3" dir="rtl">
                                <input class="form-check-input" type="checkbox" role="switch" name="status"
                                    id="rule_status">
                                <label class="form-check-label" for="rule_status"> الحالة: <span
                                        id="statusText">معطلة</span></label>
                            </div>
                        </fieldset>

                        <div class="buttons">

                            <button id="dismiss_btn" class="btn btn-info"
                                onclick="window.location='{{ route('users.home') }}'" type="button"
                                id="submitBtn">إلغاء</button>
                            <button class="btn btn-success" type="submit" id="submitBtn">تحديث بيانات الدور</button>
                        </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                </div>
            </div>
        </div>
    </div>
@endsection


@section('script')
@endsection
