@extends('layouts.admin')
@section('title')
    العملاء
@endsection
@section('homePage')
    {{ auth()->user()->company_name }}
@endsection
@section('homeLink')
    العملاء
@endsection
@section('homeLinkActive')
    تعديل بيانات عميل
@endsection
@section('links')
    <button class="btn btn-sm btn-primary"><a href="{{ route('clients.home') }}" data-bs-toggle="tooltip"
            data-bs-placement="top" data-bs-title="العودة للرئيسية"><i class="fa fa-home text-light"></i></a></button>
    <button class="btn btn-sm btn-primary"><a href="{{ route('items.setting') }}" data-bs-toggle="tooltip"
            data-bs-placement="top" data-bs-title="الاعدادات"><i class="fa fa-cogs text-light"></i></a></button>
@endsection
@section('content')
    <div class="container pt-3">

        <fieldset dir="rtl" onload="initWork()">
            <legend class=""> تعديل بيانات عميل &nbsp; &nbsp;
                <button class="btn btn-sm btn-primary"><a href="{{ route('clients.view', $client->id) }}"
                        data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="عرض البيانات"><i
                            class="fa fa-eye text-light"></i></a></button>
            </legend>
            <form class="pt-3" id="regForm" action="{{ route('clients.update') }}" method="post">
                @csrf
                <input type="hidden" name="id" value="{{ $client->id }}">
                <div class="input-group mb-3">
                    <label for="name" class="input-group-text required">اسم العميل / الشركة / المؤسسة</label>
                    <input type="text" class="form-control" name="name" required id="name"
                        value="{{ $client->name }}">
                </div>
                @error('name')
                    <div class="btn btn-outline-danger btn-sm mb-3 float-right">{{ $message }}</div>
                @enderror
                <div class="input-group mb-3">
                    <label for="scope" class="input-group-text required">نوع العميل</label>
                    <select type="text" class="form-control" name="scope" required id="scope"
                        value="{{ old('scope') }}">
                        @if (count($scopes))
                            @foreach ($scopes as $si => $item)
                                <option {{ $client->scope == $si ? 'selected' : '' }} value="{{ $si }}">
                                    {{ $item }}</option>
                            @endforeach
                        @endif
                    </select>
                    <label for="s_number" class="input-group-text required">الرقم المسلسل</label>
                    <input type="text" class="form-control" name="s_number" required id="s_number"
                        value="{{ $client->s_number }}">
                </div>
                @error('s_number')
                    <div class="btn btn-outline-danger btn-sm mb-3 float-right">{{ $message }}</div>
                @enderror

                <div class="input-group mb-3">
                    <label for="website" class="input-group-text">الموقع الالكترونى</label>
                    <input type="url" class="form-control" name="website" id="website"
                        value="{{ $client->website }}">

                    <label for="email" class="input-group-text">البريد الالكترونى</label>
                    <input type="email" class="form-control" name="email" id="email" value="{{ $client->email }}">
                </div>

                <div class="input-group mb-3">
                    <label for="phone" class="input-group-text required">رقم الهاتف / الجوال</label>
                    <input type="phone" class="form-control" name="phone" id="phone" placeholder="966-5XXXXXXXX"
                        required value="{{ $client->phone }}">
                </div>
                @error('phone')
                    <div class="btn btn-outline-danger btn-sm mb-3 float-right">{{ $message }}</div>
                @enderror

                <div class="input-group mb-3">
                    <label for="cr" class="input-group-text required">السجل التجارى</label>
                    <input type="number" class="form-control" name="cr" id="cr" placeholder="السجل التجارى"
                        required value="{{ $client->cr }}">
                    <label for="vat" class="input-group-text required">الرقم الضريبى</label>
                    <input type="number" class="form-control" name="vat" id="vat" placeholder="الرقم الضريبى"
                        required value="{{ $client->vat }}">
                </div>
                @error('cr')
                    <div class="btn btn-outline-danger btn-sm mb-3 float-right">{{ $message }}</div>
                @enderror
                @error('vat')
                    <div class="btn btn-outline-danger btn-sm mb-3 float-right">{{ $message }}</div>
                @enderror
                <!-- One "tab" for each step in the form: -->

                <div style="">
                    <br>
                    <button id="dismiss_btn" class="btn btn-outline-secondary"
                        onclick="window.location='{{ route('clients.home') }}'" type="button"
                        id="submitBtn">إلغاء</button>
                    <button class="btn btn-outline-primary" type="submit" id="submitBtn">تحديث البيانات</button>
                </div>
            </form>
        </fieldset>
    </div>

@endsection


@section('script')
    <script>
        $('.accordion-button i').click(function() {
            $(this).toggleClass('fa-folder-open fa-folder')
        })

        $('#Type').change(function() {
            if ($(this).val() == 1) {

            } else if ($(this).val() == 1) {

            }
        });
    </script>
@endsection
