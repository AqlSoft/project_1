@extends('layouts.admin')

@section('title')
    سندات الإدخال
@endsection
@section('homePage')
    {{ auth()->user()->company_name }}
@endsection
@section('homeLink')
    سندات الإدخال
@endsection
@section('homeLinkActive')
    سند إدخال جديد
@endsection
@section('links')
    <button class="btn btn-sm btn-primary"><a href="{{ route('receipt.create', 0) }}"><span class="btn-title">إضافة
                سند</span><i class="fa fa-plus text-light"></i></a></button>
    <button class="btn btn-sm btn-primary"><a href="{{ route('clients.home') }}"><span class="btn-title">العودة إلى
                العملاء</span><i class="fa fa-home text-light"></i></a></button>
@endsection

@section('content')

    <div class="container pt-3">
        <fieldset class="my-5 py-5">
            <legend>
                سنـــــدات الإستــــــلام المعتمدة
                <a data-bs-toggle="tooltip" data-bs-title="إضافة سند جديد" href="{{ route('receipts.input.create', 1) }}"><i
                        class="fa fa-plus"></i></a>
                <a data-bs-toggle="tooltip" data-bs-title="عرض كل السندات" href="{{ route('receipts.input_receipts') }}"><i
                        class="fa fa-layer-group"></i></a>
            </legend>

            <table class="w-100">
                <thead>
                    <tr>
                        <td>#</td>
                        <td>التاريخ</td>
                        <td>رقم السند</td>
                        <td>السائق</td>
                        <td>العقد</td>
                        <td>العميل</td>
                        <td>تحكم</td>
                    </tr>
                </thead>
                <tbody>
                    @if (count($inReceipts))
                        @foreach ($inReceipts as $in => $item)
                            @if ($item->status == 1)
                                <tr>
                                    <td>{{ ++$in }}</td>
                                    <td>{{ $item->hij_date }}</td>
                                    <td>{{ $item->s_number }}</td>
                                    <td>{{ $item->driver }}</td>
                                    <td>{{ $item->contract }}</td>
                                    <td>{{ $item->client }}</td>
                                    <td>
                                        <a href="{{ route('receipts.input.print', [$item->id]) }}"><i
                                                class="fa fa-print text-primary" data-bs-toggle="tooltip"
                                                data-bs-title="طباعة السند"></i></a>

                                        <a href="{{ route('receipt.cancel', [$item->id, 0]) }}"><i
                                                class="fa fa-ban text-info" data-bs-toggle="tooltip"
                                                data-bs-title="إلغاء السند"></i></a>

                                        <a href="{{ route('receipt.destroy', [$item->id, 0]) }}"><i
                                                class="fa fa-trash text-danger"data-bs-toggle="tooltip"
                                                data-bs-title="حذف السند"></i></a>
                                    </td>
                                </tr>
                            @endif
                        @endforeach
                    @else
                        <tr>
                            <td colspan="5"> لا يوجد سندات قيد التشغيل</td>
                        </tr>
                    @endif
                </tbody>
            </table>
        </fieldset>

        {{-- السندات المعنمدة لعمليات اخراج البضاعة من المخازن --}}

        <fieldset class="my-5 py-5">
            <legend>
                سنـــــدات الاخراج المعتمدة
                <a data-bs-toggle="tooltip" data-bs-title="إضافة سند جديد"
                    href="{{ route('receipts.output.create', 1) }}"><i class="fa fa-plus"></i></a>
            </legend>

            <table class="w-100">
                <thead>
                    <tr>
                        <td>#</td>
                        <td>التاريخ</td>
                        <td>رقم السند</td>
                        <td>السائق</td>
                        <td>العقد</td>
                        <td>العميل</td>
                        <td>تحكم</td>
                    </tr>
                </thead>
                <tbody>
                    @if (count($outReceipts))
                        @foreach ($outReceipts as $in => $oitem)
                            @if ($item->status == 1)
                                <tr>
                                    <td>{{ ++$in }}</td>
                                    <td>{{ $oitem->hij_date }}</td>
                                    <td>{{ $oitem->s_number }}</td>
                                    <td>{{ $oitem->driver }}</td>
                                    <td>{{ $oitem->contract }}</td>
                                    <td>{{ $oitem->client }}</td>
                                    <td>
                                        <a href="{{ route('receipts.print_output_receipts', [$oitem->id]) }}"><i
                                                class="fa fa-print text-primary" data-bs-toggle="tooltip"
                                                data-bs-title="طباعة السند"></i></a>

                                        <a href="{{ route('receipt.cancel', [$oitem->id, 0]) }}"><i
                                                class="fa fa-ban text-info" data-bs-toggle="tooltip"
                                                data-bs-title="إلغاء السند"></i></a>

                                        <a href="{{ route('receipt.destroy', [$oitem->id, 0]) }}"><i
                                                class="fa fa-trash text-danger"data-bs-toggle="tooltip"
                                                data-bs-title="حذف السند"></i></a>
                                    </td>
                                </tr>
                            @endif
                        @endforeach
                    @else
                        <tr>
                            <td colspan="5"> لا يوجد سندات قيد التشغيل</td>
                        </tr>
                    @endif
                </tbody>
            </table>
        </fieldset>

        {{-- السندات المعنمدة لعمليات ترتيب الطبالى داخل المخازن --}}

        <fieldset class="my-5 py-5">
            <legend>
                سنـــــدات ترتيب المخازن المعتمدة
                <a data-bs-toggle="tooltip" data-bs-title="إضافة سند جديد"
                    href="{{ route('receipts.createArrangeReceipt', 1) }}"><i class="fa fa-plus"></i></a>
            </legend>

            <table class="w-100">
                <thead>
                    <tr>
                        <td>#</td>
                        <td>التاريخ</td>
                        <td>رقم السند</td>
                        <td>السائق</td>
                        <td>العقد</td>
                        <td>العميل</td>
                        <td>تحكم</td>
                    </tr>
                </thead>
                <tbody>
                    @if (count($arrReceipts))
                        @foreach ($arrReceipts as $in => $aitem)
                            @if ($aitem->status == 1)
                                <tr>
                                    <td>{{ ++$in }}</td>
                                    <td>{{ $aitem->hij_date }}</td>
                                    <td>{{ $aitem->s_number }}</td>
                                    <td>{{ $aitem->driver }}</td>
                                    <td>{{ $aitem->contract }}</td>
                                    <td>{{ $aitem->client }}</td>
                                    <td>
                                        <a href="{{ route('receipts.print_arrange_receipts', [$aitem->id]) }}"><i
                                                class="fa fa-print text-primary" data-bs-toggle="tooltip"
                                                data-bs-title="طباعة السند"></i></a>

                                        <a href="{{ route('receipt.cancel', [$aitem->id, 0]) }}"><i
                                                class="fa fa-ban text-info" data-bs-toggle="tooltip"
                                                data-bs-title="إلغاء السند"></i></a>

                                        <a href="{{ route('receipt.destroy', [$aitem->id, 0]) }}"><i
                                                class="fa fa-trash text-danger"data-bs-toggle="tooltip"
                                                data-bs-title="حذف السند"></i></a>
                                    </td>
                                </tr>
                            @endif
                        @endforeach
                    @else
                        <tr>
                            <td colspan="5"> لا يوجد سندات قيد التشغيل</td>
                        </tr>
                    @endif
                </tbody>
            </table>
        </fieldset>

    </div>

@endsection
@section('script')
    <script></script>
@endsection
