@extends('layouts.admin')

@section('title')
    العمليات
@endsection
@section('homePage')
    {{ auth()->user()->company_name }}
@endsection
@section('homeLink')
    العمليات
@endsection
@section('homeLinkActive')
    سندات ترتيب المخازن
@endsection
@section('links')
    <button class="btn btn-sm btn-primary"><a href="{{ route('receipts.createInputReceipt', 1) }}"><span
                class="btn-title">إضافة
                سند</span><i class="fa fa-plus text-light"></i></a></button>
    <button class="btn btn-sm btn-primary"><a href="{{ route('clients.home') }}"><span class="btn-title">العودة إلى
                العملاء</span><i class="fa fa-home text-light"></i></a></button>
@endsection

@section('content')
    <div class="container py-5">
        <fieldset style="margin: 2em auto; padding: 2.5em 1em 2em">
            <legend>
                سنـــــدات ترتيب المخازن قيد التشغيل
                <a data-bs-toggle="tooltip" data-bs-title="إضافة سند جديد"
                    href="{{ route('receipts.createInputReceipt', 1) }}"><i class="fa fa-plus"></i></a>
            </legend>

            <table class="w-100">
                <thead>
                    <tr>
                        <td>#</td>
                        <td>التاريخ</td>
                        <td>رقم السند</td>
                        <td>السائق</td>
                        <td>العقد</td>
                        <td>العميل</td>
                        <td>تحكم</td>
                    </tr>
                </thead>
                <tbody>
                    @if (count($receipts))
                        @foreach ($receipts as $in => $item)
                            @if ($item->status == 1)
                                <tr>
                                    <td>{{ ++$in }}</td>
                                    <td>{{ $item->hij_date }}</td>
                                    <td>{{ $item->s_number }}</td>
                                    <td>{{ $item->driver }}</td>
                                    <td>{{ $item->contract->s_number }}</td>
                                    <td>{{ $item->client->name }}</td>
                                    <td>
                                        <a href="{{ route('receipts.editInputReceipt', [$item->id]) }}"><i
                                                class="fa fa-edit text-primary" data-bs-toggle="tooltip"
                                                data-bs-title="تعديل بيانات السند"></i></a>

                                        <a href="{{ route('input.entry.create', [$item->id, 0]) }}"><i
                                                class="fa fa-sign-out-alt text-info" data-bs-toggle="tooltip"
                                                data-bs-title="استلام بضاعة على السند"></i></a>

                                        <a href="{{ route('receipt.destroy', [$item->id, 0]) }}"><i
                                                class="fa fa-trash text-danger"data-bs-toggle="tooltip"
                                                data-bs-title="حذف السند"></i></a>
                                    </td>
                                </tr>
                            @endif
                        @endforeach
                    @else
                        <tr>
                            <td colspan="5"> لا يوجد سندات قيد التشغيل</td>
                        </tr>
                    @endif
                </tbody>
            </table>
        </fieldset>



    </div>
@endsection
@section('script')
    <script></script>
@endsection
