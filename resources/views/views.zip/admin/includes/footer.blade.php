
<footer class="main-footer" style="position: fixed; bottom: 0; left: 0; right: 0; height: 35px; padding: 5px 1.3em ; background: #37465a; text-align: center; ">
  <!-- To the right -->
  <div class="float-right d-none d-sm-inline">
    Anything you want
  </div>
  <!-- Default to the left -->
  <strong>Copyright &copy; 2014-2025 <a href="#" style="color: inherit">www.aklsoft.net</a>.</strong> All rights reserved. AKLSOFT<sup>TM</sup>
</footer>