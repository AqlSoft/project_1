
@if(Session::has('success'))
<div class="alert alert-success text-right">
    {{Session::get('success')}}
</div>
@endif